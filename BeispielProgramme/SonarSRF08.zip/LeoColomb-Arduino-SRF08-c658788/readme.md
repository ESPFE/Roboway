Arduino library for SRF08
=========================

Get more information at [Arduino site](http://arduino.cc/playground/Main/SonarSrf08)

Requirements
------------

* An [Arduino board](http://arduino.cc/)
* Wire library (include in the Arduino Software)
The code is provided under the MIT license please use, edit, change, and share. 

The Adxl345 library has been modified for use with this example
The Adxl345 library however is provided under the GPL V2 license.

Before loading the ADXLl345_example code, or even opening the arduino software, place the Adxl345 folder in your arduino library.

////ARDUINO LIBRARY LOCATION////
On your Mac:: In (home directory)/Documents/Arduino/libraries
On your PC:: My Documents -> Arduino -> libraries
On your Linux box: (home directory)/sketchbook/libraries